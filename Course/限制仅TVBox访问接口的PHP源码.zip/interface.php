<?php
$interface = "http://xn--4bra.live/gg.json";
//  请输入真实接口地址或者文件路径
header("location:".$interface);
?>