<?php
$uaname = "okhttp/3.12.11";
//  定义允许通过的USER_AGENT值
$nourl = "AccessDeny.html";
//  屏蔽跳转
$okurl = "interface.php";
//  通过跳转
if ( $_SERVER['HTTP_USER_AGENT'] != $uaname) {
	header("Location:".$nourl);
	exit();
} else {
	header("Location:".$okurl);
	exit();
}
?>