var rule = Object.assign(muban.mxpro,{
title:'555影视',
// host:'https://www.555dy.app',
host:'https://www.555yy2.com/',
headers:{//网站的请求头,完整支持所有的,常带ua和cookies
    'User-Agent':'Mozilla/5.0 (Linux; Android 11; M2104K10AC Build/RP1A.200720.011; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.141 Mobile Safari/537.36',
    "Cookie": "searchneed=ok"
},
});